package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> str_a1 = new ArrayList<String>();
str_a1.add("asf");
str_a1.add("rakesh");
str_a1.add("himanshu");
str_a1.add("suresh");
System.out.println("Before insertion :" + str_a1);
str_a1.add(2,"priya");
System.out.println("After insertion :" + str_a1);
str_a1.add(2,"asf");
System.out.println("Before delete :" + str_a1);
str_a1.add(2,"priya");
System.out.println("After delete :" + str_a1);


	}

}
