package DAY6;

public class Tiger extends Animals {
int lott;
	int loc;
	public void swim ()
	{
		System.out.println("Tiger swim");
	}
	public void walk () 
	{
		System.out.println("Tiger walk");
	}
	public Tiger (int lott, int loc)
	{
		this.lott = lott;
		this.loc = loc;
		
	}
	public void display() {
		System.out.println(" No of legs: " +this.nol 
				+ " Food: " + this.food
				+ " Name: "+this.name 
				+ " Gender: " + this.gender);
		
		System.out.println(" Length of the teeth: "+ this.lott + " Length of claws: " + this.loc);
	}

}
