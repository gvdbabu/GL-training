package DAY6;

public class Elephant extends Animals {

	int lot;
	int lotsuks;
public void swim ()
{
	System.out.println("Elephant swim");
}
public void walk () 
{
	System.out.println("Elephant walk");
}
public Elephant (int lot, int lotsuks)
{
	this.lot = lot;
	this.lotsuks = lotsuks;
	
}
public void display()
{
	System.out.println(" No of legs: " +this.nol 
			+ " Food: " + this.food
			+ " Name: "+this.name 
			+ " Gender: " + this.gender);
	
	System.out.println(" Length of trunk : "+ this.lot + " Length of tusks: " + this.lotsuks);
	}
}