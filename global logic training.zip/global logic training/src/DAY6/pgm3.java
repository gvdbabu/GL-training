package DAY6;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Elephant e1= new Elephant(3,2);
Tiger t1= new Tiger(4,5);
e1. nol = 4;
e1.food = "sugar cane";
e1.name = "tangoo";
e1. gender = "male";

t1.nol = 4;
t1.food = "goat";
t1. name = "timbo";
t1. gender = "male";

e1.display();
t1.display();
	}

}
