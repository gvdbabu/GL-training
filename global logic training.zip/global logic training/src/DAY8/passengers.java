package DAY8;

public class passengers {

public int slNo;
public String name;
public String from;
public String to;
public int rate;
public int noofseats;
public int total;

public void total_cost()
{
	this.total=this.rate*this.noofseats;
}



	}
