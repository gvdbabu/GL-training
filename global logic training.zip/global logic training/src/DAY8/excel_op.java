package DAY8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_op {

	public ArrayList<passengers> read_excel()
	
	{
		ArrayList<passengers> pss_al = new ArrayList<passengers>();
		try
		{
			File f = new File("C:\\training\\passengers.xlsx");
			FileInputStream fis = new FileInputStream(f);
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        XSSFSheet sh = wb.getSheet("Sheet1");
	        for (int i=1;i<=4;i++)
	        {
	        	passengers p = new passengers();
	        	XSSFRow r = sh.getRow(i);
	        	XSSFCell c = r.getCell(0);
	        	p.slNo = (int) c.getNumericCellValue();
	        	
	        	XSSFCell c1 = r.getCell(1);
	        	p.name = c1.getStringCellValue();
	        	
	        	XSSFCell c2 = r.getCell(2);
	        	p.from = c2.getStringCellValue();
	        	
	        	XSSFCell c3 = r.getCell(3);
	        	p.to = c3.getStringCellValue();
	        	
	        	XSSFCell c4 = r.getCell(4);
	        	p.rate = (int) c4.getNumericCellValue();
	        	
	        	XSSFCell c5 = r.getCell(5);
	        	p.noofseats = (int) c5.getNumericCellValue();
	        	
	        	p.total_cost();	
	        	pss_al.add(p);
	        }
	        
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return pss_al;
	}
	public void write_excel(ArrayList<passengers> p1_a1)
	{
		int row=1;
		try {
			File f=new File("C:\\training\\passengers.xlsx ");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			for(passengers p:p1_a1)
			{
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(6);
			c.setCellValue(p.total);
			row++;
			}
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}