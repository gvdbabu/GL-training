package DAY8;

import java.util.ArrayList;

public class excel {

	public static void main(String[] args) {
		ArrayList<passengers> p_a = new ArrayList<passengers>();
		excel_op ex = new excel_op();
		p_a = ex.read_excel();
		ex.write_excel(p_a);

	}

}
