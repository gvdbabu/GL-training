package assesment;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i;
		String line = "hello i am working at global logic";
extract_word(line);

	}
	
	
	public static void extract_word(String str)
	{
		String str1;
		int p=0;
		for(int i=0; i<str.length(); i++)
		{
			if(str.charAt(i)==' '&& str.charAt(i+1)!=' ')
			{
				str1=str.substring(p,i);
				p=i+1;
				count(str1);
			}
		}
	}
	public static void count(String s)
	{
		if(s.length()>5)
		{
			System.out.println(s);
			
		}
	}
}
