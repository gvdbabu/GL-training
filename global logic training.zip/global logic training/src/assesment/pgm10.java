package assesment;



public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_op ex=new excel_op();
		for(int i=1;i<=2;i++)
		{
		student s1=ex.read_excell(i);
		s1.average();
		ex.write_excel(i,s1);
		}

	}

}
