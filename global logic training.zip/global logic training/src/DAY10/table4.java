package DAY10;

public class table4 {

public int customer_id;
public String customer_name;
public String from;
public String to;
public int unitprice;
public int noofseats;
public int price;
private int total_price;

public void total_price()
{
	this.total_price = this.unitprice * this.noofseats;
}

}
