package DAY10;

public class table1 {

public int route_id;
public String from;
public String to;
public int unitprice;

}
