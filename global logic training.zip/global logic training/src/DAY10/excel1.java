package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel1 {
ArrayList<table3> t3_al;
ArrayList<table3> t2_al;
ArrayList<table3> t1_al;
	public void readt3()
	{
  try
{
	File f = new File("C:\\training\\table3.xslx");
    FileInputStream fis = new FileInputStream(f);
    XSSFWorkbook wb = new XSSFWorkbook(fis);
    XSSFSheet sh = wb.getSheet("Sheet1");
    int fr= sh.getFirstRowNum();
    int lr = sh.getLastRowNum();
    int not=lr-fr+1;
    for(int i=fr+1;i<=not-1;i++)
    {
    	table3 t3 = new table3();
    	XSSFRow r= sh.getRow(i);
    	XSSFCell c= r.getCell(0);
    	t3.customer_id = (int) c.getNumericCellValue();
    	
    	XSSFCell c1 = r.getCell(1);
    	t3.route_id = (int) c1.getNumericCellValue();
    	
    	XSSFCell c2 = r.getCell(2);
    	t3.notickets = (int) c2.getNumericCellValue();
    	
    	t3_al.add(t3);
    }
    }
  
  catch(FileNotFoundException e)
  {
	  e.printStackTrace();
  }
  catch(IOException ie)
  {
  ie.printStackTrace();
  }
  

}
 public void readt2()
 {
	 int row =1;
	 ArrayList<table2> t2_al = new ArrayList<table2>();
	 try
	 {
	 	File f = new File("C:\\training\\table2.xslx");
	     FileInputStream fis = new FileInputStream(f);
	     XSSFWorkbook wb = new XSSFWorkbook(fis);
	     XSSFSheet sh = wb.getSheet("Sheet1");
	     int fr= sh.getFirstRowNum();
	     int lr = sh.getLastRowNum();
	     int not=lr-fr+1;
	     for(int i=fr+1;i<=not-1;i++)
	     {
	     	table2 t2 = new table2();
	     	XSSFRow r= sh.getRow(i);
	     	XSSFCell c= r.getCell(0);
	     	t2.customer_id = (int) c.getNumericCellValue();
	     	
	     	XSSFCell c1 = r.getCell(1);
	     	t2.c_name = c1.getStringCellValue();
	     	
	     	t2_al.add(t2);
	     }
	     }
	   
	   catch(FileNotFoundException e)
	   {
	 	  e.printStackTrace();
	   }
	   catch(IOException ie)
	   {
	   ie.printStackTrace();
	   }
 }


public void readt1()
{
	 int row =1;
	 ArrayList<table1> t1_al = new ArrayList<table1>();
	 try
	 {
	 	File f = new File("C:\\training\\table1.xslx");
	     FileInputStream fis = new FileInputStream(f);
	     XSSFWorkbook wb = new XSSFWorkbook(fis);
	     XSSFSheet sh = wb.getSheet("Sheet1");
	     int fr= sh.getFirstRowNum();
	     int lr = sh.getLastRowNum();
	     int not=lr-fr+1;
	     for(int i=fr+1;i<=not-1;i++)
	     {
	     	table1 t1 = new table1();
	     	XSSFRow r= sh.getRow(i);
	     	XSSFCell c= r.getCell(0);
	     	t1.route_id = (int) c.getNumericCellValue();
	     	
	     	XSSFCell c1 = r.getCell(1);
	     	t1.from = c1.getStringCellValue();
	     	
	     	XSSFCell c2 = r.getCell(2);
	     	t1.to = c2.getStringCellValue();
	     	
	     	XSSFCell c3 = r.getCell(3);
	     	t1.unitprice = (int) c3.getNumericCellValue();
	     	
	     	t1_al.add(t1);
	     }
	     }
	   
	   catch(FileNotFoundException e)
	   {
	 	  e.printStackTrace();
	   }
	   catch(IOException ie)
	   {
	   ie.printStackTrace();
	   }
	   
}
}
	 
	 
	 
	 
 
 
 