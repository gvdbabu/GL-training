package DAY10;

public class table2 {

public int customer_id;
public String c_name;
}
