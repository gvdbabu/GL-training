package DAY10;

import java.util.ArrayList;

public class pgm {

	public static void main(String[] args) {
		ArrayList<table3> t3_al = new ArrayList<table3>();
		excel1 ex = new excel1();
		ex.readt3();
		ex.readt2();
		ex.readt1();
		
	}

}
