package DAY5;

import DAY3.Student;

public class excel {

	public static void main(String[] args) {
		read_excel ex=new read_excel();
		for(int i=1;i<=2;i++)
		{
		Student s1=ex.read_excell(i);
		s1.average();
		ex.write_excel(i,s1);
		}
	}

}