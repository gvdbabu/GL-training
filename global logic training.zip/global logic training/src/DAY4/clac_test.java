package DAY4;

public class clac_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
calc_v1 calc = new calc_v1();
int sum= calc.add(5, 10);
System.out.println("first sum="+sum);
float s= calc.add(2,3,4.1f);
System.out.println("second sum ="+s);
	}

}
