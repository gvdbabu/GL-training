

package DAY4;

import DAY3.college;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		college Rakesh = new college();
		Rakesh.rollno=19;
		Rakesh.m1=23;
		Rakesh.m2=45;
		Rakesh.name= "Rakesh";
		
		college Priya = new college();
		Priya.rollno=52;
		Priya.m1=32;
		Priya.m2=54;
		Priya.name= "Priya";
		
		System.out.println("rollnumber is: " +Rakesh.rollno );
		System.out.println("marks is: " +Rakesh.m1 );
		System.out.println("marks is: " +Rakesh.m2 );
		Rakesh.average(Rakesh.m1,Rakesh.m2);
		
		System.out.println("rollnumber is: " +Priya.rollno );
		System.out.println("marks is: " +Priya.m1 );
		System.out.println("marks is: " +Priya.m2 );
		Priya.average(Priya.m1,Priya.m2);
	}


	}




