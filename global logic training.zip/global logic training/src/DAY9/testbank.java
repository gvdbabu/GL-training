package DAY9;

public class testbank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bank b;
		b = new hdfc();
		System.out.println(" hdfc bank roi " + b.get_roi());
		
		b = new icici();
		System.out.println("icici bank roi " + b.get_roi());

	}

}
