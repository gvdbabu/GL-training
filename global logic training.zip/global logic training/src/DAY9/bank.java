package DAY9;

public class bank {

	public float get_roi()
	{
		return 0f;
	}
	public void display()
	{
		System.out.println("bank details");
	}
	}


