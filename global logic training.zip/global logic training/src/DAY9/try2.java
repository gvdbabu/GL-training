package DAY9;

public class try2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try1 t = new try1();
	t.setAccount_no(2002);
	t.setAccount_bal(2000);
	System.out.println("Account no is "+ t.getAccount_no()
	+ " Account bal is "+ t.getAccount_bal());
	}

}
