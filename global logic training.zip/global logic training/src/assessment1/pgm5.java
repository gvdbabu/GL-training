package assessment;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
parrots p1 = new parrots(3, 2);
owls o1 = new owls(4, 5);
p1. nol = 2;
p1.food = "mango";
p1.name = "twitter";
p1.gender = "male";

o1.nol = 2;
o1.food = "insects";
o1.name = "bagt";
o1.gender = "male";

p1.display();
o1.display();
	}

}
