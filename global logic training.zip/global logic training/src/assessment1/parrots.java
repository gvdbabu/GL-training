package assessment;

public class parrots extends birds {
	int lol;
	int lob;
	public void eat ()
	{
		System.out.println("parrot eat");
	}
	public void fly ()
	{
		System.out.println("parrot fly");
	}
	public parrots (int lol, int lob)
	{
		this.lol =lol;
		this.lob = lob;
	}
	public void display()
	{
		System.out.println(" No of legs: " +this.nol 
			+ " food: " + this.food
			+ " name: "+this.name 
			+ " Gender: " + this.gender);
		System.out.println(" Length of legs : "+ this.lol + " Length of lob: " + this.lob);
	}
	}

