package assessment;

import java.util.ArrayList;

public class student1 {

	public static void main(String[] args) {
	ArrayList<pgm7> al = new ArrayList<pgm7>();
	pgm8 p1 =new pgm8();
	al = p1.read_excel();
	p1.write_excel(al);

	}

}
