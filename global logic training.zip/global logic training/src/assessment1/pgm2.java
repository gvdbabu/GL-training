package assessment;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		int j,k,n,sum,count=0;
		ArrayList<Integer>j_al=new
				ArrayList<Integer>();
		for(k=1;k<=10000;k++)
		{
			sum=0;
			n=k;
			while(n!=0)
			{
				j=n%10;
				sum=sum+(j*j*j);
				n=n/10;
			}
			if(k==sum)
			{
				j_al.add(sum);
				count++;
			}
			if(count==5)
			{
				System.out.println(j_al);
				break;
			}
		}
		
	}

}
