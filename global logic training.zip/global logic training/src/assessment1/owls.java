package assessment;

public class owls extends birds {

	int lol;
	int lob;
	public void eat ()
	{
		System.out.println("owls eat");
	}
	public void fly ()
	{
		System.out.println("parrot fly");
	}
	public owls (int lol, int lob)
	{
		this.lol =lol;
		this.lob = lob;
	}
	public void display()
	{
		System.out.println(" No of legs: " +this.nol 
			+ " Food: " + this.food
			+ " Name: "+this.name 
			+ " Gender: " + this.gender);
		System.out.println(" Length of legs : "+ this.lol + " Length of lob: " + this.lob);
	}
	}

