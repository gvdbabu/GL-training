package assessment;

public class college {

	public static void main(String[] args) {
		student s1= new student(20,"ram",70,80);
		student s2= new student(21,"ramesh",75,55);
		student s3= new student(22,"geetha",80,66);
s1.average();
s2.average();
s3.average();
s1.display();
s2.display();
s3.display();
	}

}
