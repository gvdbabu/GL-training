package assessment;

public class birds {
int nol;
String food;
String name;
String gender;
public void eats()
{
	System.out.println("birds eat\n");
}
public void fly () {
System.out.println("birds fly\n");
}
	
	public void display()
	{
		System.out.println("no of legs : "+ this.nol
				+ "food : "+ this.food
				+ "name : "+ this.name
				+ "gender : "+ this.gender);
		
	}
}

	

