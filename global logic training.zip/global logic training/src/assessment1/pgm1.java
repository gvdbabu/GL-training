package assessment;
import java.util.ArrayList;
public class pgm1 {


	public static void main(String[] args) 
	{
	int k;
	ArrayList<Integer> k_al = new ArrayList<Integer>();
	for(k=10;k<=30;k++)
	{
		if(k%2==0)
		{
			k_al.add(k);
		}
	}
System.out.println(k_al);
	}

}
