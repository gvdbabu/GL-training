package assessment;

public class pgm7 {
int productid;
String productname;
int perunitrate;
int unitpurchased;
int price;
String grade;
public void price ()
{
	this.price=perunitrate*unitpurchased;
}
public void grade(pgm7 p)
{
	if (p.price<25000)
		this.grade = "grade a";
	else if (p.price>25000)
		this.grade= "grade b";
}
}
