package assessment;

public class student {
 int rollno;
 String name;
 int javamarks;
 int seliniummarks;
 float average;
 public student(int rollno,String name,int javamarks,int seliniummarks)
{
	this.rollno=rollno;
	this.name=name;
	this.javamarks=javamarks;
	this.seliniummarks=seliniummarks;
}
public float average()
{
	this.average=(float)(this.javamarks+this.seliniummarks)/2;
	return average;
}
public void display()
{
	if(this.average>=65)
	{
		System.out.println("rollnum is :"+this.rollno
				+ "name is : "+this.name
				+"javamarks : "+this.javamarks
				+"seliniummarks : "+ this.seliniummarks
				+"average :"+ this.average);
	}
}


}
