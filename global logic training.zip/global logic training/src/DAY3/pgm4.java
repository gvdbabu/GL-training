package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		
int marks[][]= {{99,98,97},{87,88,89}};
for(i=0;i<=2;i++)
{
	for(j=0;j<=3;j++)
	{
		System.out.println(marks [i][j]);
		/*if (max<marks[i][j])
		 * {
		 */
	}

}
	}

}
