package DAY3;

public class college {
public int rollno;
public int sub1;
public int sub2;
public String name;
public float avg;
public int m1;
public int m2;
public void average(int m1,int m2)
{
	this.avg=(float)(this.sub1+this.sub2)/2;
	System.out.println("average is :"+ this.avg);
	System.out.println();
	
	}

}
