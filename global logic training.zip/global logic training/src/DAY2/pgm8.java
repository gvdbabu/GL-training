package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=5, j=4;
while(i<10)
{
	System.out.println(i+"*"+j+"="+(i*j));
	i++;
	j=j+2;
}
	}

}
