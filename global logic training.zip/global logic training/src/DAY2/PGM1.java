package DAY2;

public class PGM1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int s = 3;
switch(5)
{
case (2):
System.out.println("two");

case (5):
System.out.println("five");

case (9):
System.out.println("nine");

default:
System.out.println("no match");
}
System.out.println("out of switch");

	}

}
