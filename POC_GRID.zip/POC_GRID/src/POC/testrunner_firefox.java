package POC;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class testrunner_firefox extends excel{
	
	WebDriver dr;
	login lp;
	Home hp;
	Cart cp;
	CheckoutPage chp;
	CheckoutOverview chow;
	WebDriverWait wait;
	static int a=1;
	String autURL,nodeURL;
	
	
	@BeforeClass
	public void a() throws MalformedURLException
	{
		
		System.setProperty("webdriver.gecko.driver","geckodriver_v26.exe");
		dr=new FirefoxDriver();
		dr.get("http://www.saucedemo.com");
		
		lp=new login(dr);
		hp=new Home(dr);
		cp=new Cart(dr);
		chp=new CheckoutPage(dr);
		chow=new CheckoutOverview(dr);
		lp.do_login("standard_user", "secret_sauce");
		
		testdata = new Object[2][1];
		for(rowno=1;rowno<=2;rowno++)
			{
				read_excel(rowno);
			}
		
	}
	@Test
	public void b()
	{
		String str=dr.findElement(By.xpath("//div[@class=\"product_label\"]")).getText();
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(str, "Products");
		sa.assertAll();
	}
	
	
	 @Test(dataProvider="data")
	public void c(String data)
	{
		 int i=hp.search_prod(data);
		hp.add_to_cart(i);
		String e_pn1=hp.get_prod_name(i);
		hp.click_cart();
		String a_pn1=cp.cartItemName(a++);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_pn1,e_pn1);	
		System.out.println("item added to cart is     "+ e_pn1+"item found in cart is            "+a_pn1);

		logfile.log(a_pn1,e_pn1);
		cp.clickContinue();
		sa.assertAll();
					
	}
	@DataProvider(name="data")
	 public Object[][] getdata() {
	
		
	return testdata;
	}
				 
		
	@Test
	public void d()
	{
		dr.get("https://www.saucedemo.com/checkout-step-one.html");
		chp.details("gvd","babu","123456");
				
		String a_pn1=chow.get_Title();
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(a_pn1,"Checkout: Overview");	
		sa.assertAll();
	
	}
	@Test
	public void e()
	{
		chow.get_ItemTotal();
		float f1=chow.get_ItemTotal();
		float f2=chow.get_ItemTax();
		float f3=chow.get_Total();
		float sum=f1+f2;
		System.out.println("Total actual value is:"+sum);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(sum, f3);
		sa.assertAll();
		chow.cartbtnfinishClick();
	}

}
