package POC;

public class product {
	public String pname;
	public String price;
	public int xpath;
	
	public product(String pname,String price,int xpath)
	{
		this.pname =pname;
		this.price=price;
		this.xpath =xpath;
	}

}
