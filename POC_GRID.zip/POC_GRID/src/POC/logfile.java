package POC;

import org.apache.log4j.Logger;

public class logfile {
	public static void log(String a,String b)
	{
		Logger log=Logger.getLogger("devpinoyLogger");
		log.debug("Expected result: "+a+" Actual result: "+b+" Test Result:=Pass");
	}

}
