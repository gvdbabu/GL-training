package POC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class login {
	
	static WebDriver dr;
	static By xname=By.xpath("//input[@placeholder='Username']");
	static By xpwd=By.xpath("//input[@placeholder='Password']");
	static By xbtn=By.xpath("//input[@type='submit']");
	
	public login(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr,this);
	
	}
	public static void enter_username(String uid)
	{
		dr.findElement(xname).sendKeys(uid);
		
	}
	public static void enter_pword(String pword)
	{
		dr.findElement(xpwd).sendKeys(pword);
		
	}
	public static void click_btn()
	{
		dr.findElement(xbtn).click();
		
	}
	public void do_login(String uid,String pword)
	{
		this.enter_username(uid);
		this.enter_pword(pword);
		this.click_btn();
	}
	public String get_loginpage_title()
	{
		return dr.getTitle();
	}
}
