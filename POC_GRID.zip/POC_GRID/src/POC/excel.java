package POC;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
	
	public static String fiLename1 ="C:\\training\\pocf.xlsx";
	public static Object[][] testdata; 
	public static int rowno,colno;
	
	public static void read_excel(int n)
	
	{
	 
		try {
		
		 System.out.println(" in get test data row " + rowno);
		 File f = new File(fiLename1); 
		 
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis); 
		XSSFSheet sheet = wb.getSheet("Sheet1");
		XSSFRow row = sheet.getRow(n);
		XSSFCell cell1 = row.getCell(0); 
		System.out.println(" in readexcel 1 : " + cell1.getStringCellValue());
		
		testdata[rowno-1][0] = cell1.getStringCellValue(); 

		System.out.println(" in readexcel 2 : " + testdata[rowno-1][0]);
		 }
		 catch (Exception e) { 
			 System.out.println(e); } 
	}
}

