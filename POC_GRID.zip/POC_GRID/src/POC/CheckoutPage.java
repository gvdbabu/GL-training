package POC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage {
	
	static WebDriver dr;
	static By fname=By.xpath("//*[@id=\"first-name\"]");
	static By lname=By.xpath("//*[@id=\"last-name\"]");
	static By pcode=By.xpath("//*[@id=\"postal-code\"]");
	static By checkoutbtn=By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input");
	static By cartbtncancel=By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/a");
	
	public CheckoutPage(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public  void enter_firstname(String firstname)
	{
		dr.findElement(fname).sendKeys(firstname);
		
	}
	public void enter_lastname(String lastname)
	{
		dr.findElement(lname).sendKeys(lastname);
		
	}
	public  void enter_postalcode(String postalcode)
	{
		dr.findElement(pcode).sendKeys(postalcode);
		
	}
	public  void cartbtnfinishClick()
	{
		dr.findElement(checkoutbtn).click();
		
	}
	public void details(String firstname,String lastname ,String postalcode)
	{
		this.enter_firstname(firstname);
		this.enter_lastname(lastname);
		this.enter_postalcode(postalcode);
		this.cartbtnfinishClick();
	}
	
}
