package DAY2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i, sum = 0;
for (i=15; i<=75;i++)
{
	while(i % 7 == 0)
	{ 
		sum = sum + i;
	}
}
System.out.println(sum);
	}

}
