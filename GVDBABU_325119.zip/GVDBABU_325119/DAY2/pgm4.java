package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i, s=0, cnt = 0;
for (i=10;i<=50;i++)
{
	if ((i%5)==0)
	{
		s=s+i;
		cnt++;
		if(cnt == 1)
			System.out.print(i);
		else
			System.out.print("+"+i);
	}
}
System.out.print("="+s);
	}

}
