package DAY3;

public class PGM2 {

	public static boolean iseven (int a)
	{
		if (a%2 == 0)
			return true;
		else 
			return false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num[] = {21,34,91,59,16,25,29,74,49,82};
int sum = 0;
for (int i=0; i<num.length; i++)
{
	if(iseven(num[i]))
	sum=sum+num[i];
}
System.out.println(sum);
	}

}
