package DAY3;

public class college {
int rollno,m1,m2;
String name;
float avg;
public void average(int m1,int m2)
{
	this.avg=(float)(this.m1+this.m2)/2;
	System.out.println("average is :"+ this.avg);
	System.out.println();
	
	}

}
