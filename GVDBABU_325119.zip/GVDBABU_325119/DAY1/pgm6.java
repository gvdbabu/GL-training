package DAY1;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 10;
int b = 20;
a += 4;
b = - 4;
System.out.println(a);
System.out.println(b);

	}

}
