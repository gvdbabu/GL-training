package sday6;

public class pgm4 {

}
