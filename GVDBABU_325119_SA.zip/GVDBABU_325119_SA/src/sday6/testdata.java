package sday6;

public class testdata {

	public String keyword,xpath,data;
}