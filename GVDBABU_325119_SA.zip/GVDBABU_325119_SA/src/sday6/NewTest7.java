package sday6;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest7 {
  @Test(priority = 0)
  public void c() { 
	  System.out.println("in test c");
  }
  @Test(priority = 2)
  public void b() 
  {
	  System.out.println("in test b");
  }
  @Test(priority = 3)
  public void a()
  {
	  System.out.println("in test a");
  }
}
