package sday6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import sday4.testdata;

public class NewTest2 {
	pgm1 pg=new pgm1();
	testdata t,t1;
  @BeforeClass
  public void a() {
	  t = new testdata();
	  t1 = new testdata();
  }
  @Test(dataProvider = "security")
  public void login(String u,String p,String r) {
	  t.uid = u;
	  t.password = p;
	  t.exp_result = r;
	  t1=pg.login(t);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(t1.act_result, t.exp_result);
	  sa.assertAll();
  }
  @DataProvider(name="security")
  public String[][] getdata()
  {
	  String[][] data = {{"gvdbabu432@gmail.com","demostart","success"},{"gvdbabu432@gmail.com","demo","failure"}};
			  
	  
	  return data;
}
  }
