package sday6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import sday4.testdata;

public class NewTest3 {
	pgm1 p=new pgm1();
	testdata t,t1;
  @Test
  public void test() {
  t = new testdata();
  t1 = new testdata();
  t.uid="gvdbabu432@gmail.com";
  t.password = "demo";
  t.exp_result="success";
  t1 = p.login(t);
  SoftAssert sa = new SoftAssert();
  sa.assertEquals(t.exp_result, t1.act_result);
  System.out.println("actualresult: :"+t.act_result+" "+" testresult::"+t1.testresult+" ");
  sa.assertAll();
  }
}
