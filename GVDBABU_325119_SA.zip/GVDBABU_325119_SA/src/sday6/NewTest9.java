package sday6;

import org.testng.annotations.Test;

public class NewTest9 {
  @Test
  public void f() {
  }
}
