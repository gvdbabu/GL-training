package assesment;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class NewTest {

 userdata input,output;
 register re;
 
  @Test(dataProvider = "provide_data")
  public void register(String a,String b,String c,String d,String e,String f) {
 
 input.gender=a;
 input.f_name=b;
 input.l_name=c;
 input.email=d;
 input.pass=e;
 input.c_pass=f;
 
 
 output=re.reg(input);
/*  System.out.println("EXPECTED RESULT:"+input.email);
 System.out.println("ACTAUL RESULT:"+output.account);*/
 
 
  }
  @AfterMethod
  public void test1() {
 
 
SoftAssert so=new SoftAssert();
 so.assertEquals(input.email, output.account);
 System.out.println("EXPECTED RESULT:"+input.email);
 System.out.println("ACTAUL RESULT:"+output.account);
 
 so.assertAll();
  }

  @DataProvider
  public String[][] provide_data() {


 String[][] data= {{"male","gvd","babu","gvdbabu5@gmail.com","qwerty","qwerty"},
{"female","gvd","babu","gvdbabu56@gmail.com","qwertyuqw","qwertyuqw"}};
 
 return data;
   
  }
  @BeforeClass
  public void beforeClass() {
 input=new userdata();
 output=new userdata();
 re=new register();
 
 
  }

}
