package assesment;

public class userdata {
String gender,f_name,l_name,email,pass,c_pass,account;
}


