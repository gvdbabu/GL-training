package sday1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class webdriver1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
	
	/*String title = dr.getTitle();
	System.out.println("title : " + title);
	
	
	/*List rb = dr.findElements(By.name("sex"));
	((WebElement) rb.get(1)).click();
	
	
	/*WebElement we1 = dr.findElement(By.id("day"));
	Select sel1 = new Select(we1);
	sel1.selectByVisibleText("30");
	
	
	/*WebElement we2 = dr.findElement(By.id("month"));
	Select sel2 = new Select(we2);
	sel2.selectByVisibleText("Mar");
	
	
	/*WebElement we3 = dr.findElement(By.id("year"));
	Select sel3 = new Select(we3);
	sel3.selectByVisibleText("1996");*/
	
	
	dr.findElement(By.name("email")).sendKeys("gvdbabu432@gmail.com");
	dr.findElement(By.name("pass")).sendKeys("hgacsftycxwjgh");
	dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
	
	String a_profileName = dr.findElement(By.id("Gvd")).getText();
	String expectedProfileName = " ";
	
	if(a_profileName.compareTo("")==0)
	{
		System.out.println("login successfull");
	}
	else
	{
		System.out.println("login not successfull");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
