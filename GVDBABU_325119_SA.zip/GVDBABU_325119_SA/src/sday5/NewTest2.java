package sday5;

import org.testng.annotations.Test;

import sday4.login_data;

public class NewTest2 {
 test_login loginobj;
 login_data ldata,ldata_out;
 @Test
 public void t1()
 {
	 ldata = new login_data();
	 ldata_out = new login_data();
	 loginobj = new test_login();
	 
	 ldata.uid= "gvdbabu432@gmail.com";
	 ldata.pwd= "demostart";
	 ldata.exp_res1="success";
	 
	 ldata_out = loginobj.login(ldata);
	 System.out.println("ldata_out.act_result : "+ ldata_out.act_result);
 }
}
