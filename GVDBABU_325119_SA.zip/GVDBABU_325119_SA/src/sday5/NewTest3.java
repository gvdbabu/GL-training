package sday5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest3 {
 @BeforeClass
 public void BC()
 {
	 System.out.println("i came to the cricket ground");
 }
 
 @AfterClass
 public void AC()
 {
	 System.out.println("now i am back to home");
 }
 
 @BeforeMethod
 public void BM()
 {
 System.out.println("hello");
}

 @AfterMethod
 public void AM()
 {
 System.out.println("bye");
 }
 @Test
 public void t1()
 {
	 System.out.println("i met mr.dhoni");
 }
 @Test
 public void t2()
 {
	 System.out.println("i had lunch with mr.virat kohli");
 }
 @Test
 public void t3()
 {
	 System.out.println("i took a pic with mr.rohith sharma");
 }
 
}
 
