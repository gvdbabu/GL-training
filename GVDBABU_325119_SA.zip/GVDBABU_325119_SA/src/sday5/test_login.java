package sday5;

import sday4.login_data;

public class test_login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public login_data login(login_data ldata) {
		// TODO Auto-generated method stub
		return null;
	}

}
