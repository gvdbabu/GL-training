package sday5;

import java.util.ArrayList;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NewTest5 {
 pgm3 p = new pgm3();
 ArrayList<testdata> al_t;
 ArrayList<testdata> al_t1;
 @BeforeClass
 public void t1()
 {
	 al_t=new ArrayList<testdata>();
	 al_t=p.read_excel();
 }
 @Test
 public void t2()
 {
	 p.login(al_t,1);
 }
 @Test
 public void t3()
 {
	 p.login(al_t,1);
 }
 @Test
 public void t4()
 {
	 p.login(al_t,1);
 }
 @Test
 public void t5()
 {
	 p.login(al_t,1);
 }
 @Test
 public void t6()
 {
	 p.login(al_t,1);
	 {
		 p.writeexcel(al_t1);
	 }
 }
}
