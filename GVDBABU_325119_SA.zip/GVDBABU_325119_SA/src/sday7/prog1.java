package sday7;

public class prog1 {

}
