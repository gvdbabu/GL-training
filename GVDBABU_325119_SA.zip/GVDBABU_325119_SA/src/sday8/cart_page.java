package sday8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cart_page {
WebDriver dr;
public cart_page(WebDriver dr) {
	this.dr=dr;
}
public String verify() {
	String s=dr.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")).getText();
	return s;
}
}
