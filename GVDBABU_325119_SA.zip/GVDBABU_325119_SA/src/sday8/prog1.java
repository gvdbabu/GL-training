package sday8;

import org.apache.log4j.Logger;

public class prog1 {
public static void main(String[]args) {
	Logger log = Logger.getLogger("devpinoyLogger");
	log.debug("Error happened");
}
}
