package sday8;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest {
	login_page lp;
	home_page hp;
	cart_page cp;
	WebDriver dr;
  @BeforeClass
  public void BC() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://www.saucedemo.com/");
		lp = new login_page(dr);
		hp = new home_page(dr);
		cp = new cart_page(dr);
  }
  @Test
  public void t1() {
	  lp.log("standard_user","secret_sauce");
	  hp.add_to_cart(1);
	  hp.click_cart();
	  String s =cp.verify();
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(s,"Sauce Labs Backpack");
	  sa.assertAll();
	  
  }
  
}
