package sday3;

public class content {
	public String firstname;
	public String lastname;
	public String mailid;
	public String password;
	public String confirmpassword;
	public String exp_res;
	public String act_res;
	public String result;

}
