package sday3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm6 {
public static content testdata;
	
	public static content read_excel() {
		content u=new content();
		try {
			File f=new File("C:\\training\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			u.firstname=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			u.lastname=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			u.mailid=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			u.password=c3.getStringCellValue();
			XSSFCell c4=r.getCell(4);
			u.confirmpassword=c4.getStringCellValue();
			
			System.out.println(u.firstname+" "+u.lastname+" "+u.mailid+" "+u.exp_res);
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return u;
	}
		// TODO Auto-generated method stub
		public static void register() {
		   System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		   WebDriver dr=new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[1]/h1")).getText();
testdata.act_res=s;
 String title=dr.getTitle();
System.out.println("title:"+title);
if(title.equals("Demo Web Shop. Register")) {
	System.out.println("title verified");
}
else {
	System.out.println("fail");
}
dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(testdata.firstname);
dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(testdata.lastname);
dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.mailid);
dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(testdata.password);
dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(testdata.confirmpassword);
dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
if(s1.equals(testdata.exp_res)) {
	testdata.result="pass";
}
else {
	testdata.result="fail";
}

	}
		public static void write_excel(content a) {

			
			try {
				File f=new File("C:\\training\\Book1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(1);
				XSSFCell c=r.createCell(6);
				c.setCellValue(a.act_res);
				XSSFCell c1=r.createCell(7);
				c1.setCellValue(a.result);
				
			     FileOutputStream fos=new FileOutputStream(f);
			     wb.write(fos);
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		public static void main(String[] args) {
			testdata=read_excel();
			register();
			write_excel(testdata);
		}

}