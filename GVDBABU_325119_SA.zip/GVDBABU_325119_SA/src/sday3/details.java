package sday3;

public class details {
public String uid;
public String password;
public String exp_res;
public String act_res;
public String test_res;

}
