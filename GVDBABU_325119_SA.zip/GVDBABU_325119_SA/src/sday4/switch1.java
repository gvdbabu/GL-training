package sday4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://www.naukri.com/");
		String hnd = dr.getWindowHandle();
		for(String handle:dr.getWindowHandles())
		{
		dr.switchTo().window(handle);
		String t = dr.getTitle();
		System.out.println(t);
		String t1 = dr.getCurrentUrl();
		System.out.println(t1);
		}
	}

}
