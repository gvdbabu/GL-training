package sday4;

public class testdata {
	public String uid;
	public String password;
	public String exp_result;
	public String exp_ermsg1;
	public String exp_ermsg2;
	public String act_result;
	public String act_ermsg1;
	public String act_ermsg2;
	public String testresult;
	

}