package sday4;

public class login_data {

public String uid,pwd,exp_res1,act_res1,test_res;
public String exp_em1,exp_em2,act_em1,act_em2;
public String act_result;
public login_data(String uid, String pwd,String exp_res,String act_res,String test_res)
{
	this.uid=uid;
	this.pwd=pwd;
	this.exp_res1=exp_res;
	this.act_res1=act_res;
	this.test_res=test_res;
}
public login_data()
{
	
}
public void display()
{
	System.out.println("uid : "+ this.uid
	+"\n pwd : "+ this.pwd
	+"\n exp res :"+ this.exp_res1
	+"\n act res :"+ this.act_res1
	+"\n test res :"+ this.test_res
	+"\n exp_em1 :"+ this.exp_em1
	+"\n exp_em2 :"+ this.exp_em2
	+"\n act_em1 :"+ this.act_em1
	+"\n act_em2 :"+ this.act_em2
	+"\n=======================");
	
}
}
