package nov15;

public class login_test_data {
public String uid;
public String pwd;
}
