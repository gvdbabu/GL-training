package nov15;

public class keyword_sh {
public String TC_ID;
public String step_no;
public String keyword;
public String Xpath;
public String Test_Data;
}
