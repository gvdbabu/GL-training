package nov15;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {
	public static String filename = "C:\\training\\nov15";
			public static String kw_sheet = "KEYWORD";
			public static String tc_sheet = "TC_SELECTION_SH";
			public static XSSFSheet kw_sh_obj, tc_sh_obj, td_sh_obj;
			public static ArrayList<login_test_data> td_al;
			
}

			
			public static XSSFSheet set_sheet(String sheetname)
			{
				XSSFSheet sh = null;
				try {
					File f=new File(filename);
					FileInputStream fis = new FileInputStream(f);
					XSSFWorkbook wb = new XSSFWorkbook(fis);
					sh = wb.getSheet(sheetname);
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				return sh;
			}
			public static keyword_sh read_kw_sh(int i) throws IOException {
				keyword_sh kw = new keyword_sh();
				
				kw_sh_obj = set_sheet(kw_sheet);
				
				XSSFRow rw = kw_sh_obj.getRow(i);
				kw.TC_ID = rw.getCell(0).getStringCellValue();
				kw.step_no = rw.getCell(1).getStringCellValue();
				kw.keyword = rw.getCell(2).getStringCellValue();
				kw.Xpath = rw.getCell(3).getStringCellValue();
				kw.Test_Data = rw.getCell(4).getStringCellValue();
				return kw;
			}
public static void get_test_data(String shname,int total_rows,int total_cols)
{
	td_sh_obj = set_sheet(shname);
	login_test_data td;
	td_al = new ArrayList<login_test_data>();
	
	int r,c;
	for(r=1;r<=total_rows;r++)
	{
		td=new login_test_data();
		td.uid = td_sh_obj.getRow(r).getCell(0).getStringCellValue();
		td.pwd = td_sh_obj.getRow(r).getCell(1).getStringCellValue();
		System.out.println("test data row : "+ r + "uid : " + td.uid + "pwd : "+ td.pwd);
		td_al.add(td);
	}
	
}
}
