package nov12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class methodclass {
	WebDriver dr;
	public String register(String s1,String s2,String s3,String s4,String s5) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(s1);
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(s2);
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(s3);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(s4);
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(s5);
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		String ar = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.close();
		return ar;
	}

}
