package nov12; 

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider {
	methodclass mc;
	String ar,er;
	@BeforeClass
	public void BC() {
		mc = new methodclass();
	}
	@Test(dataProvider="security")
	public void test1(String s1,String s2,String s3,String s4,String s5) {
		er= s3;
		ar = mc.register(s1, s2, s3, s4, s5);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(ar, er);
		System.out.println("Actual Result : "+ar+", Expected Result :"+er);
		sa.assertAll();
	}
@DataProvider(name="security")
public String[][] provide_data() {
	String[][] validData = {{"gvd","babu","gvdbabu432@gmail.com","demostart","demostart"},
			{"sachin","tendulkar","sachin2@gmail.com","sachin2","sachin2"}};
	return validData;
}
}
