package nov12;

import org.openqa.selenium.WebDriver;

public class register_main {
public static void main(String[]args) {
	String kw,loc,td;
	WebDriver dr=null;
	webelements we= new webelements(dr);
	register_excel ex = new register_excel();
	for(int r=1;r<=16;r++) {
		kw=ex.read_excel(r, 3);
		loc=ex.read_excel(r, 4);
		td=ex.read_excel(r, 5);
		switch (kw)
		{
		case "launchchrome" :
			we.launchchrome(td);
			break;
			
		case "enter_text" :
			we.enter_txt(loc,td);
			break;
			
		case "click_btn" :
			we.click(loc);
			break;
			
		case "verify" :
			we.verify(loc,td);
			break;
			
		case "closebrowser" :
			we.closebr();
			break;
			
			
		}
	}
}
}
