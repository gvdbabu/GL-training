package nov12;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelements {
	WebDriver dr;
	webelements(WebDriver dr){
		this.dr=dr;
	}
public void enter_txt(String xp, String data) {
	dr.findElement(By.xpath(xp)).sendKeys(data);
}
public void radio(String xp) {

	
		dr.findElement(By.xpath(xp)).click();	
		}

	public void click(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	public void verify(String xp,String data) {
		String s;
		//int flag = 0;
		s=dr.findElement(By.xpath(xp)).getText();
		if(s.equals(data)) {
			System.out.println("Successfully logged in");
			
	}
		else {
			System.out.println("registration not completed");
			
		}
	}
	public void closebr() {
		dr.close();
	}
	public void launchchrome(String url) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	
}
}
