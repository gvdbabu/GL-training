$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters login data and click ok button",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 6284399300,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_data_and_click_ok_button()"
});
formatter.result({
  "duration": 1401528700,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 34552100,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [gvdbabu43@gmail.com] but found [gvdbabu432@gmail.com]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test1.home_page_is_displayed(test1.java:41)\r\n\tat ✽.Then Home page is displayed(a.feature:6)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 8,
  "name": "login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters invalid login data and click ok button",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 5760788300,
  "status": "passed"
});
formatter.match({
  "location": "test2.user_enters_login_data_and_click_ok_button()"
});
formatter.result({
  "duration": 8529892000,
  "status": "passed"
});
formatter.match({
  "location": "test2.home_page_is_displayed()"
});
formatter.result({
  "duration": 138900,
  "status": "passed"
});
});