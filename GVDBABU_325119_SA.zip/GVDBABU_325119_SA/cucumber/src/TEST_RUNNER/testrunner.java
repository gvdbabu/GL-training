package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="features",glue="STEP_DEF",
tags="@ROUND1")
					//plugin="html:reports/cucumber-report")

public class testrunner extends AbstractTestNGCucumberTests {

}
