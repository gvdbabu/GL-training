package TEST_RUNNER;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class parallel1 {
	WebDriver dr;
	@Test
	public void t1()
	{
		System.out.println("in t1 - start");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("in t1 - stop");
	}
@Test
public void t2()
{
	System.out.println("in t2 - start");
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	System.out.println("in t2 - stop");
}
}
