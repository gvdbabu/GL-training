package STEP_DEF;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	   System.out.println("Login page is displayed");
	   
	   System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		
		
	}

	@When("^user enters login data and click ok button$")
	public void user_enters_login_data_and_click_ok_button() throws Throwable {
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("gvdbabu432@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("demostart");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    
	}
	
	

	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	   String s = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	   System.out.println(s);
	   SoftAssert sa = new SoftAssert();
		  sa.assertEquals(s,"gvdbabu43@gmail.com");
		  sa.assertAll();
		  
	}

}
