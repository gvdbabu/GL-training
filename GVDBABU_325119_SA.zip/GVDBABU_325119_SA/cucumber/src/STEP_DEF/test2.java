package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
	WebDriver dr;
	@When("^user enters invalid login data and click ok button$")
	public void user_enters_login_data_and_click_ok_button() throws Throwable 
	{
		 System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
			dr = new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com/");
			
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("gvdbabu4@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("demostart");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    
}
	@Then("^Home page is not displayed$")
	public void home_page_is_displayed() throws Throwable {
		System.out.println("Login is not successful");
		
		
		
	}	
		
	}