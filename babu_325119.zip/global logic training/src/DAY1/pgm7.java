package DAY1;

import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("enter any character");
Scanner sc = new Scanner(System.in);
char ch = sc.next().charAt(0);
if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
	System.out.println("the character is vowel");
else
	System.out.println("it is constant");
	}

}
