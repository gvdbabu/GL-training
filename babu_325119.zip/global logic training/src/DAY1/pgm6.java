package DAY1;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 20;
//int b = 20;
int x=0;
int y=0;
y=++a;
System.out.println(a);
x=a++;
System.out.println(a);
System.out.println(y);
System.out.println(x);
//System.out.println(b);

	}

}
