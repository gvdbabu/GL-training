package DAY3;

public class PGM1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int std []= {77,75,78,79,80,81};
int sum = 0;
float avg;
for(int i = 0; i<= 5; i++)
{
	sum = sum +std[i];
	
}
avg =sum/6;
System.out.println(avg);
	}

}
