package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n = 10, m=0, p;
p =n/m;
System.out.println(p);
	{
		System.out.println("in catch blk");
	}
}
}
