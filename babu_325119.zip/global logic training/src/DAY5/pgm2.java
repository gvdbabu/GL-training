package DAY5;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a []= {1,2,3};
System.out.println(a[3]);
	}

}
