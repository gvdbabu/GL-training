package assesment;

public class student {
	public  int rollno;
	public	String name;
	public int sub1;
	public int sub2;
	public float avg;
			
		
			
	public float average()
	{
		this.avg=(this.sub1+this.sub2)/2;
		return avg;
		
	}

}
