package assesment;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i,j=0,k=0,b=0,h=0;
		int a1[]= new int[10];
		int a2[] = new int[10];
		for(i=10; i<=30; i++)
		{
			if(i % 3==0)
			{
				a1[j]=i;
				j++;
		}
			
				if(i % 5 ==0)
				{
					a2[k]=i;
					k++;
				}
				
for(b=0; b<=j; b++)
{
for(h=0; h<=k; h++)
{
	if((a1[b]+a2[h])>30 && (a1[b]+a2[h])<40)
{
	System.out.println(a1[b]+" +  "+a2[h]+"  =  "+(a1[b]+a2[h]));
}
}
}
		}
		
	}

}
