package DAY6;

public class Animals {
int nol;
String food;
String name;
String gender;
public void eats()
{
	System.out.println("animal walks\n");
}
public void swim()
{
	System.out.println("animal swim\n");
}
public void display() {
	System.out.println(" No of legs: " +this.nol
			+ " Food: " + this.food
			+ " Name: "+this.name 
			+ " Gender: " + this.gender);
}

	}
