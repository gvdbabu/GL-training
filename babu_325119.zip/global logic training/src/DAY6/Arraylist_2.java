package DAY6;
import java.util.ArrayList;
		// TODO Auto-generated method stub
import DAY4.Student2;
import DAY4.student3;
public class Arraylist_2
{
	ArrayList<student3> std_al = new ArrayList<student3>();
	private ArrayList<student3> std_a2;	
	public void create_al()
	{
		student3 s1 = new student3("Ramesh",101,80,90);
		student3 s2 = new student3("Ramesh1",102,85,95);
		std_al.add(s1);
		std_a2.add(s2);
	}
	public Void display_a1()
	{
		for(student3 s : std_al )
		{
			System.out.println("name : " + s.name
			               +"rollno : " + s.rollno
			               +"sel marks : " + s.sel
			               +"jav marks : " + s.jav
			               +"avg : " + s.avg );}}
	public static void main(String[] args)
	{
		ArrayList al = new ArrayList();
		al.create_a1();
		System.out.println("output of display ");
		al.display_al();
		
	
		
}
	}

}
