package DAY4;

public class Student2 {

	
		// TODO Auto-generated method stub
 public int rollnum;
public String name;
public int m1;
public int m2;
public float average;
		
public Student2(int rollnum, String name, int m1, int m2)
{
			this.rollnum=rollnum;
			this.name=name;
			this.m1 = m1;
			this.m2 = m2;
		}
public void display() {
	System.out.println("rollnum: :"+ rollnum);
	System.out.println("name: :"+ name);
	System.out.println("m1: :"+ m1);
	System.out.println("m2: :"+ m2);
}
		
		public static void main(String[]args) {
			Student2 s =new Student2(10,"rakesh",85,88);
			s.display();
		}
	
}

