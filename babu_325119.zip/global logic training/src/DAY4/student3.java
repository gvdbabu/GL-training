package DAY4;

public class student3 {
		// TODO Auto-generated method stub
public String name;
public int rollno;
public int sel;
public int jav;
public float avg;
public float average()
{
	avg = (sel+jav)/2;
	return avg;
}
public student3(String name,int rollno,int sel,int jav)
{
	this.name = name;
	this.rollno = rollno;
	this.sel = sel;
	this.jav = jav;
}
	}

